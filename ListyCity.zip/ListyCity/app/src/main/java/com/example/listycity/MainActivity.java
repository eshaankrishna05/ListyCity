package com.example.listycity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private String selectedCity = null;
    private int selectedPosition = -1;
    private ArrayList<String> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Local UI references
        ListView cityList = findViewById(R.id.city_list);
        Button addButton = findViewById(R.id.add_button);
        EditText cityInput = findViewById(R.id.city_input);
        Button confirmButton = findViewById(R.id.confirm_button);
        Button deleteButton = findViewById(R.id.delete_button);

        // Initialize city list
        dataList = new ArrayList<>();
        dataList.add("Edmonton");
        dataList.add("Montréal");

        // Adapter setup
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this, R.layout.content, R.id.city_text, dataList);
        cityList.setAdapter(cityAdapter);

        // City selection logic
        cityList.setOnItemClickListener((parent, view, position, id) -> {
            selectedCity = dataList.get(position);
            selectedPosition = position;

            for (int i = 0; i < cityList.getChildCount(); i++) {
                cityList.getChildAt(i).setBackgroundColor(Color.TRANSPARENT);
            }
            view.setBackgroundColor(Color.LTGRAY);
        });

        // Show input when "ADD CITY" is pressed
        addButton.setOnClickListener(v -> {
            cityInput.setVisibility(View.VISIBLE);
            confirmButton.setVisibility(View.VISIBLE);
            cityInput.requestFocus();
        });

        // Add city when "CONFIRM" is pressed
        confirmButton.setOnClickListener(v -> {
            String newCity = cityInput.getText().toString().trim();
            if (!newCity.isEmpty()) {
                dataList.add(newCity);
                cityAdapter.notifyDataSetChanged();
                cityInput.setText("");
                cityInput.setVisibility(View.GONE);
                confirmButton.setVisibility(View.GONE);
            }
        });

        // Delete selected city
        deleteButton.setOnClickListener(v -> {
            if (selectedCity != null && selectedPosition >= 0) {
                dataList.remove(selectedPosition);
                cityAdapter.notifyDataSetChanged();
                selectedCity = null;
                selectedPosition = -1;
            }
        });
    }
}
